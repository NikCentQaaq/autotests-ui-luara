import allure
from playwright.sync_api import Playwright, Page
from pytest_playwright.pytest_playwright import browser_type

from config import settings, Browser




def initialize_playwright_page(
        playwright: Playwright,
        browser_type: Browser,
        test_name: str,
        storage_state: str | None = None
) -> Page:
    """
    Создает и настраивает объект Page Playwright для выполнения теста.

    Выполняет:
    - запуск указанного браузера;
    - создание нового BrowserContext;
    - настройку базового URL, записи видео, trace и storage state;
    - создание новой страницы.

    После завершения теста:
    - сохраняет trace и видео;
    - прикладывает артефакты к отчету Allure;
    - закрывает браузер.
    """

    browser = playwright[browser_type].launch(headless=settings.headless)
    context = browser.new_context(
        base_url=settings.get_base_url(),
        storage_state=storage_state,
        record_video_dir=settings.videos_dir
    )
    context.tracing.start(screenshots=True, snapshots=True, sources=True)
    page = context.new_page()

    yield page

    context.tracing.stop(path=settings.tracing_dir.joinpath(f'{test_name}.zip'))
    browser.close()

    allure.attach.file(settings.tracing_dir.joinpath(f'{test_name}.zip'), name='trace', extension='zip')
    allure.attach.file(page.video.path(), name='video', attachment_type=allure.attachment_type.WEBM)







