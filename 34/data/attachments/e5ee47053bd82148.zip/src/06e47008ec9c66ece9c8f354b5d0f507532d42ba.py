

import allure
from playwright.sync_api import Locator, expect

from elements.base_element import BaseElement
from tools.logger import get_logger

logger = get_logger('INPUT')

class Input(BaseElement):


    def get_value(self) -> str:
        step = f'Получение значения {self.type_of} "{self.name}"'
        with allure.step(step):
            logger.info(step)
            return self.locator.input_value()




    def fill(self, value: str | int, nth: int=0):
        step = f'Ввод значения {value} в {self.type_of} "{self.name}" '

        with allure.step(step):
            locator = self.get_locator(nth)
            logger.info(step)

            locator.fill(value)


    def fill_locator_input(self, value: str | int, nth: int=0):
        step = f'Ввод значения {value} в {self.type_of} "{self.name}" '

        with allure.step(step):
            locator = self.get_locator(nth).locator('input')
            logger.info(step)

            locator.fill(value)


    def check_have_value(self, value: str | int, nth: int=0):
        step = f'Проверка, что {self.type_of} "{self.name}" имеет значение {value}'

        with allure.step(step):
            locator = self.get_locator(nth)
            logger.info(step)

            expect(locator).to_have_value(value)



    def check_placeholder(self, value: str, nth: int=0):
        step = f'Проверка Плейсхолдера {self.type_of} "{self.name}" имеет значение {value}'

        with allure.step(step):
            locator = self.get_locator(nth)
            logger.info(step)

            expect(locator).to_have_attribute("placeholder", value)

