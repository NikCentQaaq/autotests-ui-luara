import allure
from playwright.sync_api import Page, expect

from components.headers.catalog_header_component import CatalogHeaderComponent
from components.headers.header_component import HeaderComponent
from components.product.product_size import SizeProductComponent
from elements.button import Button
from elements.container import Container
from elements.image import Image
from elements.link import Link
from elements.text import Text
from pages.base_page import BasePage
from tools.enums.category import Category, Metall
from tools.function import parse_int_price, check_equal
from tools.models.product_info import ProductInfo


class ProductPage(BasePage):

    def __init__(self, page: Page):
        super().__init__(page)

        self.header = HeaderComponent(page)
        self.catalog_header = CatalogHeaderComponent(page)
        self.size = SizeProductComponent(page)

        self.image = Image(page.locator('img.img_body'), 'Изображение')
        self.name_product = Text(page.locator('div.bx h1.ttl'), 'Название')
        self.price = Text(page.locator('div.kc-current_price'), 'Цена')
        self.add_button = Button(page.get_by_role('link', name='Добавить в корзину'), 'Добавить в корзину')

        self.popup_success_add_product = Text(page.locator('div.notyf__message'), 'Товар успешно добавлен в корзину')

        self.articul = Text(page.get_by_text('Арт:'), 'Артикул')

        accordion = page.locator(".product-accordion__item").filter( has=page.get_by_role("button", name="Характеристики"))
        self.characteristic_button = Button(accordion.get_by_role("button", name="Характеристики"), "Характеристики")
        self.characteristics_panel = Container(accordion.locator(".product-accordion__panel"), "Панель характеристик")
        self.metall = Text(accordion.locator("div").filter(has=page.locator("dt:text-is('Металл')")).locator("dd"),"Металл")


    @allure.step("Проверка уведомления об успешном добавлении товара")
    def check_popup_success_add(self):
        self.popup_success_add_product.check_visible()


    @allure.step('Получение Артикула товара')
    def get_product_articul(self):
        return self.articul.get_text().replace("Арт:", "").strip()

    @allure.step('Получение Названия и Артикула товара')
    def get_product_name_and_articul(self) -> str:
        name = self.name_product.get_text()
        return name

    @allure.step('Получение Названия товара')
    def get_product_name(self):
        name = self.get_product_name_and_articul().replace(f"{self.get_product_articul()}", "").strip()
        return name



    @allure.step('Получение Цены товара')
    def get_product_price(self) -> int:
        return parse_int_price(self.price.get_text())


    @allure.step('Получение данных продукта')
    def get_product_info(self) -> ProductInfo:
        return {
            "name": self.get_product_name(),
            "articul": self.get_product_articul(),
            "price": self.get_product_price(),
            "size": self.size.get_selected_size()
        }

    @allure.step("Нажатие кнопки 'Добавить в корзину'")
    def click_add_button(self):
        self.add_button.check_visible()
        self.add_button.check_enabled()

        self.add_button.click()

    def check_num_cart_into_header(self, expected_num: int):
        self.header.check_quantity(expected_num)



    @allure.step("Добавление товара в корзину")
    def add_to_cart(self):
        self.size.select_size_if_needed()

        if self.size.split.get_locator().is_visible(timeout=1000):
            self.size.split.check_visible()

        self.click_add_button()
        self.check_popup_success_add()






    @allure.step('Проверка заголовка каталога для категории "{category_name}"')
    def check_catalog_header(self, category_name: Category):
        self.catalog_header.check_title_category(category_name)
        self.catalog_header.check_title_catalog_filter()


    @allure.step('Проверка, что название товара содержит категорию "{category_name}"')
    def check_name_have_category(self, category_name: Category):
        self.name_product.check_contain_text(category_name.lower())


    @allure.step('Проверка элементов на странице продукта')
    def check_elements(self):
        self.image.check_visible()
        self.name_product.check_visible()
        self.price.check_visible()

        self.add_button.check_visible()
        self.add_button.check_contain_text('Добавить в корзину')

    @allure.step('Получение Металла товара')
    def get_product_metall(self):
        metall = self.metall.get_text().strip()
        return metall

    @allure.step("Раскрыть характеристики")
    def open_characteristics_product(self):
        button = self.characteristic_button.get_locator()
        panel = self.characteristics_panel.get_locator()

        button.scroll_into_view_if_needed()

        expect(button).to_be_visible()
        expect(button).to_be_enabled()

        if not panel.is_visible():
            button.click()
            expect(panel).to_be_visible(timeout=10000)

        self.metall.check_visible()

    @allure.step('Проверка металла товара, ожидается {expected}')
    def check_metall_product(self, expected : Metall):
        self.open_characteristics_product()

        metall = self.metall.get_text()
        check_equal(metall, expected)

    @allure.step("Добавление текущего товара в корзину")
    def add_product_to_cart(self) -> ProductInfo:

        self.size.select_size_if_needed()

        product = self.get_product_info()

        self.add_to_cart()

        return product

    @allure.step('Возвращение назад на страницу каталога')
    def back_to_catalog_page(self):
        self.go_back()








