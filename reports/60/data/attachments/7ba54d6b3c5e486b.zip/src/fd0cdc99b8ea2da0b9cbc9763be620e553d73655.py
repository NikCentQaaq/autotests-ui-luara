import allure
import pytest

from pages.catalog_page import CatalogPage
from pages.product_page import ProductPage
from tools.enums.allure_enum import AllureStory, AllureEpic, AllureFeature
from tools.enums.category import Metall, Category


@allure.epic(AllureEpic.UI)
@allure.feature(AllureFeature.FILTER)
class TestFilterCatalog:

    @allure.story(AllureStory.FILTER)
    @allure.title("Сброс выбранных фильтров")
    @pytest.mark.smoke
    def test_reset_selected_filters(self, opened_catalog_page: CatalogPage):

        opened_catalog_page.filter.select_metall(Metall.GOLD)
        opened_catalog_page.filter.select_category(Category.RINGS)
        opened_catalog_page.filter.fill_price_range(60000, 150000)
        opened_catalog_page.filter.click_show_result()

        opened_catalog_page.reset_all_filter()

        opened_catalog_page.check_current_url()
        opened_catalog_page.check_filters_reset()



    @allure.story(AllureStory.FILTER)
    @allure.title("Сохранение выбранных фильтров после обновления страницы")
    @pytest.mark.smoke
    @pytest.mark.parametrize("metall, category, min_price, max_price", [
        pytest.param(Metall.SILVER, Category.BRACELETS, 10000, 30000, id='silver_bracelets')
    ])
    def test_selected_filters_saved_after_refresh(
            self,
            metall: Metall,
            category: Category,
            min_price: int,
            max_price: int,
            opened_catalog_page: CatalogPage
    ):
        opened_catalog_page.filter.select_metall(metall)
        opened_catalog_page.filter.select_category(category)
        opened_catalog_page.filter.fill_price_range(min_price, max_price)
        opened_catalog_page.filter.click_show_result()

        opened_catalog_page.reload()

        opened_catalog_page.filter.metall.check_selected(metall)
        opened_catalog_page.filter.category.check_selected(category)
        opened_catalog_page.filter.price.check_min_price(min_price)
        opened_catalog_page.filter.price.check_max_price(max_price)

        opened_catalog_page.check_current_url_contains(metall.url_contains)
        opened_catalog_page.check_current_url_contains(category.url_contains)

















    @allure.story(AllureStory.PRICE_FILTER)
    @allure.title("Фильтрация по диапазону цен")
    @pytest.mark.parametrize("min_price, max_price", [
        pytest.param(10000, 50000, id='base', marks=pytest.mark.smoke),
        pytest.param(0, 60000, id='min 0', marks=pytest.mark.regression),

        pytest.param(9990, 9990, id='equal_min_max', marks=pytest.mark.regression),
        pytest.param(2500000, 2690000, id='most_expensive_product', marks=pytest.mark.regression)])
    def test_filter_price(self, min_price: int, max_price: int,  opened_catalog_page: CatalogPage):
        opened_catalog_page.filter.fill_price_range(min_price, max_price)

        opened_catalog_page.filter.check_result_count()
        opened_catalog_page.filter.click_show_result()

        opened_catalog_page.check_price_filter_url(min_price, max_price)
        opened_catalog_page.check_title(f'цена от {min_price} до {max_price}')
        opened_catalog_page.check_range_prices(min_price, max_price)



    @allure.story(AllureStory.PRICE_FILTER)
    @allure.title("Фильтрация по диапазону цен без результатов")
    @allure.description("Проверка отображения пустого каталога при выборе диапазона цен, для которого отсутствуют товары.")
    @pytest.mark.regression
    @pytest.mark.negative
    @pytest.mark.parametrize("min_price, max_price", [
        pytest.param('2690001', '2690001', id='above_max_price'),
        pytest.param('', '1899', id='less_min_prise'),
        pytest.param('50991', '54899', id='dont_exist_prise'),
        pytest.param('10000', '5000', id='min_is_greater_than_max')
    ])
    def test_filter_price_no_results(self, min_price: int, max_price: int,  opened_catalog_page: CatalogPage):
        opened_catalog_page.filter.fill_price_range(min_price, max_price)

        opened_catalog_page.filter.check_results_count_zero()
        opened_catalog_page.filter.click_show_result()

        opened_catalog_page.check_cards_count(0)


    @allure.story(AllureStory.PRICE_FILTER)
    @allure.title("Ввод некорректных символов в поле 'Цена от'")
    @pytest.mark.regression
    @pytest.mark.negative
    @pytest.mark.xfail(reason='Известная проблема: отсутствует валидация нечислового ввода в поле "Цена от"')
    @pytest.mark.parametrize("min_price", [
        pytest.param('фыва', id='cyrillic'),
        pytest.param('!!!!', id='special_chars'),
        pytest.param('abc', id='latin'),
        pytest.param('1фис345', id='mixed')
    ])
    def test_min_price_filter_invalid_input(self, min_price: int, opened_catalog_page: CatalogPage):
        opened_catalog_page.filter.price.fill_min_price(min_price)
        opened_catalog_page.filter.click_show_result()
        opened_catalog_page.filter.price.check_min_price('')




    @allure.story(AllureStory.PRICE_FILTER)
    @allure.title("Ввод некорректных символов в поле 'Цена до'")
    @pytest.mark.regression
    @pytest.mark.negative
    @pytest.mark.xfail(reason='Известная проблема: отсутствует валидация нечислового ввода в поле "Цена до"')
    @pytest.mark.parametrize("max_price", [
        pytest.param('фыва', id='cyrillic'),
        pytest.param('!!!!', id='special_chars'),
        pytest.param('abc', id='latin'),
        pytest.param('1фис345', id='mixed')
    ])
    def test_max_price_filter_invalid_input(self, max_price: int, opened_catalog_page: CatalogPage):
        opened_catalog_page.filter.price.fill_max_price(max_price)
        opened_catalog_page.filter.click_show_result()
        opened_catalog_page.filter.price.check_max_price('')







    @allure.story(AllureStory.METALL_FILTER)
    @allure.title("Фильтрация по металлу изделий")
    @pytest.mark.parametrize("metall, text_value", [
        pytest.param(Metall.SILVER, 'серебр',  id='silver',marks=pytest.mark.smoke),
        pytest.param(Metall.GOLD, 'золот',  id='gold', marks=pytest.mark.regression)])
    def test_select_metall(self, metall: Metall, text_value:str , opened_catalog_page: CatalogPage):
        opened_catalog_page.filter.select_metall(metall)

        opened_catalog_page.filter.check_result_count()
        opened_catalog_page.filter.click_show_result()

        opened_catalog_page.check_current_url_expected(metall.url_pattern)
        opened_catalog_page.check_names_contain_text(text_value)


    @allure.story(AllureStory.METALL_FILTER)
    @allure.title("Фильтрация по металлу изделий: ювелирный сплав")
    def test_select_jewelry_metall(self, opened_catalog_page: CatalogPage, product_page: ProductPage):
        opened_catalog_page.filter.select_metall(Metall.JEWELRY_ALLOY)

        opened_catalog_page.filter.check_result_count()
        opened_catalog_page.filter.click_show_result()

        opened_catalog_page.check_current_url_expected(Metall.JEWELRY_ALLOY.url_pattern)

        opened_catalog_page.open_product_card_random()

        product_page.check_current_url()
        product_page.check_elements()

        product_page.check_metall_product(Metall.JEWELRY_ALLOY)



    @allure.story(AllureStory.METALL_FILTER)
    @allure.title("Фильтрация по категории изделий")
    @pytest.mark.parametrize("category", [
        pytest.param(Category.RINGS,  id='rings', marks=pytest.mark.smoke),
        pytest.param(Category.BROOCHES, id='earrings', marks=pytest.mark.regression),
        pytest.param(Category.BRACELETS, id='bracelets', marks=pytest.mark.regression),
        pytest.param(Category.NECKLACES, id='necklaces', marks=pytest.mark.regression),
        pytest.param(Category.CUFFLINKS,  id='pedants', marks=pytest.mark.regression)
    ])
    def test_select_category(self, category,  opened_catalog_page: CatalogPage):
        opened_catalog_page.filter.select_category(category)
        opened_catalog_page.filter.click_show_result()

        opened_catalog_page.check_current_url_expected(category.url_pattern)
        opened_catalog_page.check_names_contain_text(category.text_name)






    @pytest.mark.regression
    @pytest.mark.parametrize("category", [
        pytest.param(Category.RINGS, id='rings'),
        pytest.param(Category.BRACELETS, id='bracelets')])
    @pytest.mark.parametrize("metall, metall_text", [
        pytest.param(Metall.SILVER, 'серебр', id='silver'),
        pytest.param(Metall.GOLD, 'золот', id='gold')])
    @pytest.mark.parametrize("min_price, max_price", [
        pytest.param(10000, 100000, id='10k-100k'),
        pytest.param(20000, 200000, id='20k-200k')])
    @pytest.mark.xfail(reason="BUG: Фильтр цены работает некорректно для некоторых комбинаций фильтров")
    def test_combined_filters(self, metall, category,min_price, max_price, metall_text, category_text, opened_catalog_page: CatalogPage):

        opened_catalog_page.filter.select_metall(metall)
        opened_catalog_page.filter.select_category(category)
        opened_catalog_page.filter.fill_price_range(min_price, max_price)

        opened_catalog_page.filter.check_result_count()
        opened_catalog_page.filter.click_show_result()

        opened_catalog_page.check_current_url_contains(category.url_contains)
        opened_catalog_page.check_current_url_contains(metall.url_contains)
        opened_catalog_page.check_current_url_contains(f"from-{min_price}-to-{max_price}")


        opened_catalog_page.check_names_contain_text(metall_text)
        opened_catalog_page.check_names_contain_text(category_text)
        opened_catalog_page.check_range_prices(min_price, max_price)





